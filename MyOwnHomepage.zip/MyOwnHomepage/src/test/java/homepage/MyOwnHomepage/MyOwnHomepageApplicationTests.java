package homepage.MyOwnHomepage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyOwnHomepageApplicationTests {

	@Test
	void contextLoads() {
	}

}
