package homepage.MyOwnHomepage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyOwnHomepageApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyOwnHomepageApplication.class, args);
	}

}
